CREATE TABLE some_entity (
    id character varying(45) NOT NULL,
    enum_val character varying(15)
);
