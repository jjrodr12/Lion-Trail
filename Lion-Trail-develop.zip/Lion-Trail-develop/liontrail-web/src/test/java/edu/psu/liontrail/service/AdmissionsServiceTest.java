package edu.psu.liontrail.service;

import org.junit.Ignore;
import org.junit.Test;

public class AdmissionsServiceTest {
  
  @Test
  @Ignore
  public void testAcceptAppliction() {
    //Setup application data
    //Admissions Officer accepts application
    //Verify that application accepted
    //Verify that number of positions in major was decremented
  }
  
  @Test
  @Ignore
  public void testRejectApplication() {
    //Setup application data
    //Admissions Officer rejects application
    //Verify application is rejected
    //Verify that number of psoitions in major is unchanged
  }

}
