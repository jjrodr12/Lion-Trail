package edu.psu.liontrail.enumeration;

public enum ApplicationStatus {
  SUBMITTED,
  ACCEPTED,
  REJECTED;

}
