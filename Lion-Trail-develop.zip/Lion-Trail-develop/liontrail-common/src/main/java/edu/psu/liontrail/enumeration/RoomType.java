package edu.psu.liontrail.enumeration;

public enum RoomType {
  
  CLASSROOM,
  OFFICE,
  BATHROOM,
  CLOSET,
  COMPUTER_LAB,
  RESEARCH_LAB;

}
