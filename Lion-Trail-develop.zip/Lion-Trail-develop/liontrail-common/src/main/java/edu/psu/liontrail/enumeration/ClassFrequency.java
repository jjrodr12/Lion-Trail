package edu.psu.liontrail.enumeration;

public enum ClassFrequency {
  
  MONDAY_WEDNESDAY_FRIDAY,
  MONDAY_WEDNESDAY,
  MONDAY,
  TUESDAY,
  WEDNESDAY,
  THURSDAY,
  FRIDAY,
  TUESDAY_THURSDAY;

}
