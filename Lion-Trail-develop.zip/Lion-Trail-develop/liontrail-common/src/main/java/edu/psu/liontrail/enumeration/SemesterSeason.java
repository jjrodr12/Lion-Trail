package edu.psu.liontrail.enumeration;

public enum SemesterSeason {
  
  SPRING,
  SUMMER,
  FALL;

}
