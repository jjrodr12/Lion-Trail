package edu.psu.liontrail.enumeration;

public enum DegreeLevel {
  
  BA,
  BS,
  MS,
  PHD;

}
