package edu.psu.liontrail.enumeration;

public enum Departments {
  
  ENGINEERING,
  ARTS,
  BUSINESS,
  MEDICINE,
  LAW,
  MATH;
  

}
